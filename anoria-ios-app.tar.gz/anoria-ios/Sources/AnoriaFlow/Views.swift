import SwiftUI
import Charts

// MARK: - Timeline View
struct TimelineView: View {
    @ObservedObject var emotionEngine: EmotionEngine
    @State private var selectedTimeRange: TimeRange = .day
    
    enum TimeRange: String, CaseIterable {
        case day = "24H"
        case week = "7D"
        case month = "30D"
    }
    
    var body: some View {
        ZStack {
            AnimatedGradientBackground()
            
            ScrollView {
                VStack(spacing: 24) {
                    // Header
                    HStack {
                        Text("Emotion Timeline")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundStyle(.white)
                        
                        Spacer()
                    }
                    .padding(.horizontal)
                    .padding(.top, 20)
                    
                    // Time range selector
                    Picker("Time Range", selection: $selectedTimeRange) {
                        ForEach(TimeRange.allCases, id: \.self) { range in
                            Text(range.rawValue).tag(range)
                        }
                    }
                    .pickerStyle(.segmented)
                    .padding(.horizontal)
                    
                    // Emotion graph
                    EmotionGraphView(history: emotionEngine.emotionHistory)
                        .frame(height: 250)
                        .padding(.horizontal)
                    
                    // Peak moments
                    PeakMomentsView(history: emotionEngine.emotionHistory)
                        .padding(.horizontal)
                    
                    // Patterns detected
                    PatternsView()
                        .padding(.horizontal)
                    
                    Spacer(minLength: 100)
                }
            }
        }
    }
}

// MARK: - Emotion Graph View
struct EmotionGraphView: View {
    let history: [(Date, EmotionState)]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Last 24 Hours")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white.opacity(0.7))
            
            ZStack {
                // Background grid
                VStack(spacing: 0) {
                    ForEach(0..<4) { _ in
                        Divider()
                            .background(Color.white.opacity(0.1))
                        Spacer()
                    }
                }
                
                // Emotion line chart
                Canvas { context, size in
                    let data = Array(history.suffix(24))
                    guard data.count > 1 else { return }
                    
                    let stepX = size.width / CGFloat(data.count - 1)
                    
                    var path = Path()
                    for (index, (_, emotion)) in data.enumerated() {
                        let x = stepX * CGFloat(index)
                        let y = size.height * (1 - emotion.intensity / 100)
                        
                        if index == 0 {
                            path.move(to: CGPoint(x: x, y: y))
                        } else {
                            path.addLine(to: CGPoint(x: x, y: y))
                        }
                        
                        // Draw points
                        let pointRect = CGRect(x: x - 4, y: y - 4, width: 8, height: 8)
                        context.fill(
                            Circle().path(in: pointRect),
                            with: .color(emotion.color)
                        )
                    }
                    
                    // Draw line with gradient
                    context.stroke(
                        path,
                        with: .linearGradient(
                            Gradient(colors: [Color.cyan, Color.purple, Color.green]),
                            startPoint: .leading,
                            endPoint: .trailing
                        ),
                        lineWidth: 3
                    )
                }
            }
            .frame(height: 180)
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(.ultraThinMaterial)
            )
        }
    }
}

// MARK: - Peak Moments View
struct PeakMomentsView: View {
    let history: [(Date, EmotionState)]
    
    var peakMoment: (Date, EmotionState)? {
        history.max(by: { $0.1.intensity < $1.1.intensity })
    }
    
    var lowMoment: (Date, EmotionState)? {
        history.min(by: { $0.1.intensity < $1.1.intensity })
    }
    
    var body: some View {
        VStack(spacing: 16) {
            if let peak = peakMoment {
                PeakMomentCard(
                    title: "Peak Moment",
                    time: peak.0,
                    emotion: peak.1,
                    icon: "arrow.up.circle.fill",
                    color: .green
                )
            }
            
            if let low = lowMoment {
                PeakMomentCard(
                    title: "Lowest Point",
                    time: low.0,
                    emotion: low.1,
                    icon: "arrow.down.circle.fill",
                    color: .red
                )
            }
        }
    }
}

struct PeakMomentCard: View {
    let title: String
    let time: Date
    let emotion: EmotionState
    let icon: String
    let color: Color
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: icon)
                .font(.system(size: 32))
                .foregroundStyle(color)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(.white.opacity(0.7))
                
                Text(time, style: .time)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.white)
                
                Text(emotion.name)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(emotion.color)
            }
            
            Spacer()
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(color.opacity(0.3), lineWidth: 1)
                )
        )
    }
}

// MARK: - Patterns View
struct PatternsView: View {
    let patterns = [
        "Morning energy typically builds after 9 AM",
        "Focus peaks during afternoon (2-4 PM)",
        "Music boosts your mood by ~18%",
        "Movement increases energy by 15 points"
    ]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Patterns Detected")
                .font(.system(size: 20, weight: .bold))
                .foregroundStyle(.white)
            
            ForEach(patterns, id: \.self) { pattern in
                HStack(spacing: 12) {
                    Image(systemName: "sparkles")
                        .foregroundStyle(Color.cyan)
                    
                    Text(pattern)
                        .font(.system(size: 15))
                        .foregroundStyle(.white.opacity(0.9))
                    
                    Spacer()
                }
                .padding(16)
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(.ultraThinMaterial)
                )
            }
        }
    }
}

// MARK: - Sensor View
struct SensorView: View {
    @ObservedObject var emotionEngine: EmotionEngine
    
    var body: some View {
        ZStack {
            AnimatedGradientBackground()
            
            ScrollView {
                VStack(spacing: 24) {
                    // Header
                    HStack {
                        Text("Live Signals")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundStyle(.white)
                        
                        Spacer()
                        
                        Circle()
                            .fill(Color.green)
                            .frame(width: 12, height: 12)
                            .overlay(
                                Circle()
                                    .stroke(Color.green.opacity(0.3), lineWidth: 8)
                                    .scaleEffect(1.5)
                            )
                    }
                    .padding(.horizontal)
                    .padding(.top, 20)
                    
                    // Sensor readings
                    ForEach([SensorType.heartRate, .hrv, .eda, .temperature, .audio], id: \.name) { type in
                        SensorCardView(
                            type: type,
                            readings: emotionEngine.sensorReadings[type] ?? []
                        )
                        .padding(.horizontal)
                    }
                    
                    Spacer(minLength: 100)
                }
            }
        }
    }
}

// MARK: - Sensor Card View
struct SensorCardView: View {
    let type: SensorType
    let readings: [SensorReading]
    
    var currentValue: Double {
        readings.last?.value ?? 0
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(type.name)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(.white)
                    
                    HStack(baseline: .firstTextBaseline, spacing: 4) {
                        Text(String(format: "%.1f", currentValue))
                            .font(.system(size: 28, weight: .bold, design: .rounded))
                            .foregroundStyle(type.color)
                        
                        Text(type.unit)
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(.white.opacity(0.6))
                    }
                }
                
                Spacer()
            }
            
            // Waveform visualization
            WaveformView(readings: readings, color: type.color)
                .frame(height: 80)
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(type.color.opacity(0.3), lineWidth: 1)
                )
        )
    }
}

// MARK: - Waveform View
struct WaveformView: View {
    let readings: [SensorReading]
    let color: Color
    
    var body: some View {
        Canvas { context, size in
            guard readings.count > 1 else { return }
            
            let values = readings.map { $0.value }
            let minValue = values.min() ?? 0
            let maxValue = values.max() ?? 100
            let range = maxValue - minValue
            
            var path = Path()
            let stepX = size.width / CGFloat(readings.count - 1)
            
            for (index, reading) in readings.enumerated() {
                let x = stepX * CGFloat(index)
                let normalizedValue = range > 0 ? (reading.value - minValue) / range : 0.5
                let y = size.height * (1 - normalizedValue)
                
                if index == 0 {
                    path.move(to: CGPoint(x: x, y: y))
                } else {
                    path.addLine(to: CGPoint(x: x, y: y))
                }
            }
            
            // Filled area under the line
            var fillPath = path
            fillPath.addLine(to: CGPoint(x: size.width, y: size.height))
            fillPath.addLine(to: CGPoint(x: 0, y: size.height))
            fillPath.closeSubpath()
            
            context.fill(
                fillPath,
                with: .linearGradient(
                    Gradient(colors: [color.opacity(0.3), color.opacity(0.0)]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            )
            
            context.stroke(
                path,
                with: .color(color),
                lineWidth: 2
            )
        }
    }
}

// MARK: - Recommendations View
struct RecommendationsView: View {
    @ObservedObject var emotionEngine: EmotionEngine
    
    let allRecommendations = [
        Recommendation(
            title: "Listen",
            description: "Weightless by Marconi Union - scientifically proven to reduce anxiety by 65%",
            action: "Play on Spotify",
            icon: "music.note",
            color: Color(hex: "1DB954"),
            type: .listen
        ),
        Recommendation(
            title: "Breathe",
            description: "Box Breathing - 4-4-4-4 pattern to restore balance",
            action: "Start Session",
            icon: "wind",
            color: Color(hex: "5AC8FA"),
            type: .breathe
        ),
        Recommendation(
            title: "Move",
            description: "A 10-minute walk typically boosts your energy by 15 points",
            action: "Start Walk",
            icon: "figure.walk",
            color: Color(hex: "32D74B"),
            type: .move
        ),
        Recommendation(
            title: "Connect",
            description: "Your friend Sarah usually boosts your mood by 23 points",
            action: "Send Message",
            icon: "message.fill",
            color: Color(hex: "FF9500"),
            type: .connect
        )
    ]
    
    var body: some View {
        ZStack {
            AnimatedGradientBackground()
            
            ScrollView {
                VStack(spacing: 24) {
                    // Header
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("For You")
                                .font(.system(size: 32, weight: .bold))
                                .foregroundStyle(.white)
                            
                            Text("Based on your Flow Score (\(emotionEngine.flowScore))")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundStyle(.white.opacity(0.6))
                        }
                        
                        Spacer()
                    }
                    .padding(.horizontal)
                    .padding(.top, 20)
                    
                    // Recommendations
                    ForEach(allRecommendations, id: \.title) { recommendation in
                        SmartRecommendationCard(recommendation: recommendation)
                            .padding(.horizontal)
                    }
                    
                    Spacer(minLength: 100)
                }
            }
        }
    }
}

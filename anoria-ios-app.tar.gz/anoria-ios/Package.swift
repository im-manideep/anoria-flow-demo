// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "AnoriaFlow",
    platforms: [
        .iOS(.v17)
    ],
    products: [
        .library(
            name: "AnoriaFlow",
            targets: ["AnoriaFlow"]),
    ],
    targets: [
        .target(
            name: "AnoriaFlow"),
    ]
)

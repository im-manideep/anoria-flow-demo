import SwiftUI
import Combine

// MARK: - Emotion State Model
struct EmotionState {
    let name: String
    let intensity: Double // 0-100
    let color: Color
    let gradientColors: [Color]
    let description: String
}

extension EmotionState {
    static let radiating = EmotionState(
        name: "Radiating",
        intensity: 85,
        color: Color(hex: "00FF87"),
        gradientColors: [Color(hex: "00FF87"), Color(hex: "00D9FF")],
        description: "You're in your element - energy flowing freely"
    )
    
    static let focused = EmotionState(
        name: "Focused",
        intensity: 78,
        color: Color(hex: "0066FF"),
        gradientColors: [Color(hex: "0066FF"), Color(hex: "9933FF")],
        description: "Deep concentration - perfect for complex work"
    )
    
    static let scattered = EmotionState(
        name: "Scattered",
        intensity: 35,
        color: Color(hex: "FF3B30"),
        gradientColors: [Color(hex: "FF3B30"), Color(hex: "FF9500")],
        description: "Energy fragmented - time to reset"
    )
    
    static let calm = EmotionState(
        name: "Calm",
        intensity: 65,
        color: Color(hex: "007AFF"),
        gradientColors: [Color(hex: "007AFF"), Color(hex: "5AC8FA")],
        description: "Peaceful and centered - ready for anything"
    )
    
    static let energized = EmotionState(
        name: "Energized",
        intensity: 92,
        color: Color(hex: "FFD60A"),
        gradientColors: [Color(hex: "FFD60A"), Color(hex: "32D74B")],
        description: "High vitality - tackle that challenging task"
    )
    
    static let all: [EmotionState] = [radiating, focused, scattered, calm, energized]
}

// MARK: - Recommendation Model
struct Recommendation {
    let title: String
    let description: String
    let action: String
    let icon: String
    let color: Color
    let type: RecommendationType
}

enum RecommendationType {
    case listen, breathe, move, connect, focus
}

// MARK: - Sensor Reading Model
struct SensorReading: Identifiable {
    let id = UUID()
    let timestamp: Date
    let value: Double
    let type: SensorType
}

enum SensorType {
    case heartRate, hrv, eda, temperature, audio
    
    var name: String {
        switch self {
        case .heartRate: return "Heart Rate"
        case .hrv: return "HRV"
        case .eda: return "Skin Conductance"
        case .temperature: return "Temperature"
        case .audio: return "Audio Context"
        }
    }
    
    var unit: String {
        switch self {
        case .heartRate: return "BPM"
        case .hrv: return "ms"
        case .eda: return "µS"
        case .temperature: return "°C"
        case .audio: return "dB"
        }
    }
    
    var color: Color {
        switch self {
        case .heartRate: return .red
        case .hrv: return .purple
        case .eda: return .cyan
        case .temperature: return .orange
        case .audio: return .green
        }
    }
}

// MARK: - Emotion Engine (Real-time simulation)
class EmotionEngine: ObservableObject {
    @Published var currentEmotion: EmotionState = .radiating
    @Published var flowScore: Int = 82
    @Published var energy: Int = 76
    @Published var mood: Int = 85
    @Published var focus: Int = 78
    @Published var currentRecommendation: Recommendation
    @Published var sensorReadings: [SensorType: [SensorReading]] = [:]
    @Published var emotionHistory: [(Date, EmotionState)] = []
    
    private var cancellables = Set<AnyCancellable>()
    private var timer: Timer?
    
    init() {
        // Initialize with default recommendation
        self.currentRecommendation = Recommendation(
            title: "Perfect Timing",
            description: "Your focus is high - ideal time for deep work on that important project",
            action: "Start Focus Session",
            icon: "brain.head.profile",
            color: Color(hex: "9933FF"),
            type: .focus
        )
        
        // Initialize sensor readings
        initializeSensorReadings()
    }
    
    func startTracking() {
        // Simulate real-time emotion changes
        timer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: true) { [weak self] _ in
            self?.updateEmotionState()
            self?.updateSensorReadings()
        }
    }
    
    private func updateEmotionState() {
        // Simulate emotional state transitions
        let randomChange = Double.random(in: -10...10)
        
        // Update metrics with some randomness
        energy = max(20, min(100, energy + Int.random(in: -5...5)))
        mood = max(20, min(100, mood + Int.random(in: -5...5)))
        focus = max(20, min(100, focus + Int.random(in: -5...5)))
        
        // Calculate flow score
        flowScore = (energy + mood + focus) / 3
        
        // Select appropriate emotion based on flow score
        if flowScore > 80 {
            currentEmotion = Bool.random() ? .radiating : .energized
        } else if flowScore > 60 {
            currentEmotion = Bool.random() ? .focused : .calm
        } else {
            currentEmotion = .scattered
        }
        
        // Add to history
        emotionHistory.append((Date(), currentEmotion))
        if emotionHistory.count > 100 {
            emotionHistory.removeFirst()
        }
        
        // Update recommendation
        updateRecommendation()
    }
    
    private func updateRecommendation() {
        let recommendations: [Recommendation] = [
            Recommendation(
                title: "Listen",
                description: "Weightless by Marconi Union - scientifically proven to reduce anxiety by 65%",
                action: "Play on Spotify",
                icon: "music.note",
                color: Color(hex: "1DB954"),
                type: .listen
            ),
            Recommendation(
                title: "Breathe",
                description: "Box Breathing - 4-4-4-4 pattern to restore balance",
                action: "Start 5 min session",
                icon: "wind",
                color: Color(hex: "5AC8FA"),
                type: .breathe
            ),
            Recommendation(
                title: "Move",
                description: "A 10-minute walk typically boosts your energy by 15 points",
                action: "Start Walk",
                icon: "figure.walk",
                color: Color(hex: "32D74B"),
                type: .move
            ),
            Recommendation(
                title: "Connect",
                description: "Your friend Sarah usually boosts your mood by 23 points",
                action: "Send Message",
                icon: "message.fill",
                color: Color(hex: "FF9500"),
                type: .connect
            ),
            Recommendation(
                title: "Focus Time",
                description: "Your concentration is peaking - perfect for deep work",
                action: "Start Focus Session",
                icon: "brain.head.profile",
                color: Color(hex: "9933FF"),
                type: .focus
            )
        ]
        
        // Select recommendation based on current state
        if currentEmotion.name == "Scattered" {
            currentRecommendation = recommendations[1] // Breathe
        } else if flowScore > 75 {
            currentRecommendation = recommendations[4] // Focus
        } else if energy < 50 {
            currentRecommendation = recommendations[2] // Move
        } else {
            currentRecommendation = recommendations.randomElement()!
        }
    }
    
    private func initializeSensorReadings() {
        let now = Date()
        for type in [SensorType.heartRate, .hrv, .eda, .temperature, .audio] {
            var readings: [SensorReading] = []
            for i in 0..<50 {
                let timestamp = now.addingTimeInterval(TimeInterval(-i * 2))
                let value: Double
                switch type {
                case .heartRate:
                    value = Double.random(in: 60...80)
                case .hrv:
                    value = Double.random(in: 50...80)
                case .eda:
                    value = Double.random(in: 1.0...4.0)
                case .temperature:
                    value = Double.random(in: 36.0...37.5)
                case .audio:
                    value = Double.random(in: 30...70)
                }
                readings.append(SensorReading(timestamp: timestamp, value: value, type: type))
            }
            sensorReadings[type] = readings.reversed()
        }
    }
    
    private func updateSensorReadings() {
        let now = Date()
        for type in [SensorType.heartRate, .hrv, .eda, .temperature, .audio] {
            var readings = sensorReadings[type] ?? []
            
            // Get last value for smooth transitions
            let lastValue = readings.last?.value ?? 0
            let variation: Double
            let newValue: Double
            
            switch type {
            case .heartRate:
                variation = Double.random(in: -3...3)
                newValue = max(60, min(100, lastValue + variation))
            case .hrv:
                variation = Double.random(in: -5...5)
                newValue = max(40, min(90, lastValue + variation))
            case .eda:
                variation = Double.random(in: -0.3...0.3)
                newValue = max(1.0, min(5.0, lastValue + variation))
            case .temperature:
                variation = Double.random(in: -0.1...0.1)
                newValue = max(36.0, min(38.0, lastValue + variation))
            case .audio:
                variation = Double.random(in: -5...5)
                newValue = max(20, min(80, lastValue + variation))
            }
            
            readings.append(SensorReading(timestamp: now, value: newValue, type: type))
            
            // Keep only last 50 readings
            if readings.count > 50 {
                readings.removeFirst()
            }
            
            sensorReadings[type] = readings
        }
    }
    
    deinit {
        timer?.invalidate()
    }
}

// MARK: - Color Extension
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }
        
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue:  Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

# 🛠️ Anoria Flow - Setup Instructions

## Two Ways to Run This App

---

## Method 1: Swift Package (Fastest) ⚡

**Perfect for quick testing and development**

### Steps:
1. Open Terminal and navigate to the `anoria-ios` folder:
   ```bash
   cd path/to/anoria-ios
   ```

2. Open the package in Xcode:
   ```bash
   open Package.swift
   ```

3. Wait for Xcode to resolve dependencies (takes ~30 seconds)

4. Select a simulator:
   - Click the device dropdown in Xcode toolbar
   - Choose "iPhone 15 Pro" (recommended)

5. Build and run:
   - Press `Cmd + R`
   - Or click the ▶️ Play button

6. The app will launch in the simulator!

---

## Method 2: Create Full Xcode Project 📱

**For production-ready setup with full control**

### Prerequisites:
- Xcode 15.0 or later
- macOS 13.0 (Ventura) or later

### Step-by-Step:

#### 1. Create New Xcode Project

Open Xcode and create a new project:
- File → New → Project
- Choose "iOS" → "App"
- Product Name: **AnoriaFlow**
- Interface: **SwiftUI**
- Language: **Swift**
- Storage: None
- Include Tests: Optional

#### 2. Add Source Files

Copy all `.swift` files from `Sources/AnoriaFlow/` to your new Xcode project:
- ContentView.swift
- Models.swift
- Components.swift
- Views.swift

**How to add:**
- Drag and drop files into Xcode project navigator
- OR Right-click project → Add Files to "AnoriaFlow"
- Make sure "Copy items if needed" is checked

#### 3. Update Info.plist

Replace the default Info.plist with the one from this package, or manually add:
```xml
<key>UIUserInterfaceStyle</key>
<string>Dark</string>
```

#### 4. Configure Build Settings

In Xcode:
- Select your project in the navigator
- Under "General" tab:
  - Display Name: **Anoria Flow**
  - Bundle Identifier: `com.yourname.anoriaflow`
  - Version: **1.0**
  - Minimum Deployments: **iOS 17.0**

#### 5. Run!

- Select iPhone 15 Pro simulator
- Press `Cmd + R`

---

## 🎯 Troubleshooting

### "Cannot find type 'some-type' in scope"
- Make sure all 4 Swift files are added to the project
- Check file membership (right panel → Target Membership)

### "Failed to build for simulator"
- Clean build folder: `Cmd + Shift + K`
- Delete derived data: `Cmd + Opt + Shift + K`
- Restart Xcode

### App crashes on launch
- Check iOS version is 17.0+
- Verify all files are properly added
- Look at Xcode console for error messages

### Animations look choppy
- Enable "Debug → Disable Debug Slow Animations"
- Use a newer simulator (iPhone 15 Pro)
- Or test on a physical device

---

## 🚀 Running on Physical Device

### Requirements:
- iPhone running iOS 17.0 or later
- Apple Developer account (free tier works!)
- USB cable

### Steps:

1. **Connect your iPhone** to Mac via USB

2. **Trust your Mac** on iPhone when prompted

3. **Select your device** in Xcode:
   - Click device dropdown
   - Choose your iPhone

4. **Sign the app**:
   - Select project in navigator
   - Under "Signing & Capabilities"
   - Team: Select your Apple ID
   - Automatically manage signing: ✓

5. **Build and run** (`Cmd + R`)

6. **Trust developer on iPhone**:
   - Settings → General → VPN & Device Management
   - Trust your developer certificate
   - Run app again

---

## 📦 Alternative: Export as App Bundle

### Create a runnable .app file:

1. In Xcode: Product → Archive
2. Distribute App → Custom → Copy App
3. Export to folder
4. Share the .app file

**Recipients can:**
- Drag to Applications
- Right-click → Open (to bypass Gatekeeper)
- Run on their simulator

---

## 🎨 Customization Tips

### Change Colors
Edit the `Color(hex:)` values in `Models.swift`:
```swift
static let radiating = EmotionState(
    name: "Radiating",
    color: Color(hex: "YOUR_COLOR_HERE"),
    // ...
)
```

### Adjust Animation Speed
Modify duration values in `ContentView.swift`:
```swift
withAnimation(.easeInOut(duration: 3.0)) {
    // Change 3.0 to your preferred speed
}
```

### Add More Emotions
Add to `EmotionState` in `Models.swift`:
```swift
static let yourEmotion = EmotionState(
    name: "Your Emotion",
    intensity: 80,
    color: Color(hex: "COLOR"),
    gradientColors: [Color(hex: "COLOR1"), Color(hex: "COLOR2")],
    description: "Description here"
)
```

---

## 🧪 Testing Tips

### Test Different States
Modify `updateEmotionState()` in `EmotionEngine` to simulate specific scenarios:
```swift
// Force high energy state
energy = 95
mood = 90
focus = 85
```

### View in Different Devices
- iPhone SE (small screen)
- iPhone 15 Pro (standard)
- iPhone 15 Pro Max (large)

### Test Animations
- Enable slow animations: Debug → Slow Animations
- Watch for performance issues
- Check memory usage in Debug Navigator

---

## 📱 TestFlight Distribution (Optional)

To share with the Anoria team:

1. **Enroll in Apple Developer Program** ($99/year)

2. **Archive the app**:
   - Product → Archive
   - Distribute App → App Store Connect

3. **Upload to TestFlight**:
   - Login to App Store Connect
   - My Apps → TestFlight
   - Add external testers
   - Share link with Anoria team

---

## 🎓 Learning Resources

### SwiftUI
- [Apple's SwiftUI Tutorials](https://developer.apple.com/tutorials/swiftui)
- [Hacking with Swift](https://www.hackingwithswift.com/)

### Animations
- [SwiftUI Animations Guide](https://developer.apple.com/documentation/swiftui/animation)
- [Advanced SwiftUI Animations](https://www.swiftanytime.com/)

### Combine
- [Using Combine](https://developer.apple.com/documentation/combine)
- [Combine Framework Guide](https://www.raywenderlich.com/books/combine-asynchronous-programming-with-swift)

---

## 💬 Need Help?

If you encounter issues:
1. Check Xcode console for errors
2. Verify all files are added
3. Clean and rebuild
4. Restart Xcode
5. Check iOS version compatibility

---

## ✅ Final Checklist

Before submitting:
- [ ] App builds successfully
- [ ] All animations work smoothly
- [ ] Tested on multiple simulators
- [ ] No console errors
- [ ] UI looks polished
- [ ] README.md reviewed
- [ ] Screenshots taken (optional)
- [ ] Demo video recorded (optional)

---

**You're all set! 🎉**

Enjoy exploring the Anoria Flow demo app!

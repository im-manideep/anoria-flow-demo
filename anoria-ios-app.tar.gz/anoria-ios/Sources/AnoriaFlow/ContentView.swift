import SwiftUI

@main
struct AnoriaFlowApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}

// MARK: - Main Content View
struct ContentView: View {
    @StateObject private var emotionEngine = EmotionEngine()
    @State private var showingSensorDetail = false
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            DashboardView(emotionEngine: emotionEngine)
                .tabItem {
                    Image(systemName: "heart.circle.fill")
                    Text("Flow")
                }
                .tag(0)
            
            TimelineView(emotionEngine: emotionEngine)
                .tabItem {
                    Image(systemName: "chart.xyaxis.line")
                    Text("Timeline")
                }
                .tag(1)
            
            SensorView(emotionEngine: emotionEngine)
                .tabItem {
                    Image(systemName: "waveform.path.ecg")
                    Text("Sensors")
                }
                .tag(2)
            
            RecommendationsView(emotionEngine: emotionEngine)
                .tabItem {
                    Image(systemName: "sparkles")
                    Text("For You")
                }
                .tag(3)
        }
        .accentColor(.cyan)
    }
}

// MARK: - Dashboard View
struct DashboardView: View {
    @ObservedObject var emotionEngine: EmotionEngine
    @State private var rotationAngle: Double = 0
    @State private var pulseScale: CGFloat = 1.0
    
    var body: some View {
        ZStack {
            // Animated gradient background
            AnimatedGradientBackground()
            
            ScrollView {
                VStack(spacing: 30) {
                    // Header
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Flow Score")
                                .font(.system(size: 16, weight: .medium))
                                .foregroundStyle(.white.opacity(0.7))
                            
                            Text("Real-time EQ")
                                .font(.system(size: 28, weight: .bold))
                                .foregroundStyle(.white)
                        }
                        
                        Spacer()
                        
                        // Bracelet connection status
                        BraceletConnectionView()
                    }
                    .padding(.horizontal)
                    .padding(.top, 20)
                    
                    // Main emotion card - ULTRA PREMIUM
                    EmotionCardView(emotion: emotionEngine.currentEmotion)
                        .scaleEffect(pulseScale)
                        .rotation3DEffect(
                            .degrees(rotationAngle),
                            axis: (x: 0, y: 1, z: 0),
                            perspective: 0.3
                        )
                    
                    // Flow Score - Large beautiful number
                    FlowScoreDisplay(score: emotionEngine.flowScore)
                    
                    // Energy, Mood, Focus bars
                    VStack(spacing: 16) {
                        MetricBarView(
                            title: "Energy",
                            value: emotionEngine.energy,
                            color: .green,
                            icon: "bolt.fill"
                        )
                        
                        MetricBarView(
                            title: "Mood",
                            value: emotionEngine.mood,
                            color: .cyan,
                            icon: "face.smiling.fill"
                        )
                        
                        MetricBarView(
                            title: "Focus",
                            value: emotionEngine.focus,
                            color: .purple,
                            icon: "brain.head.profile"
                        )
                    }
                    .padding(.horizontal)
                    
                    // Smart recommendation card
                    SmartRecommendationCard(
                        recommendation: emotionEngine.currentRecommendation
                    )
                    .padding(.horizontal)
                    
                    // Recent activity preview
                    RecentActivityPreview(emotionEngine: emotionEngine)
                        .padding(.horizontal)
                    
                    Spacer(minLength: 100)
                }
            }
        }
        .onAppear {
            emotionEngine.startTracking()
            startAnimations()
        }
    }
    
    private func startAnimations() {
        // Gentle breathing animation
        withAnimation(.easeInOut(duration: 3.0).repeatForever(autoreverses: true)) {
            pulseScale = 1.05
        }
        
        // Subtle rotation
        withAnimation(.linear(duration: 20.0).repeatForever(autoreverses: false)) {
            rotationAngle = 360
        }
    }
}

// MARK: - Animated Gradient Background
struct AnimatedGradientBackground: View {
    @State private var animateGradient = false
    
    var body: some View {
        LinearGradient(
            colors: animateGradient ? [
                Color(hex: "0A0E27"),
                Color(hex: "1A1F3A"),
                Color(hex: "0F1429")
            ] : [
                Color(hex: "0F1429"),
                Color(hex: "1A1F3A"),
                Color(hex: "0A0E27")
            ],
            startPoint: animateGradient ? .topLeading : .bottomLeading,
            endPoint: animateGradient ? .bottomTrailing : .topTrailing
        )
        .ignoresSafeArea()
        .onAppear {
            withAnimation(.easeInOut(duration: 5.0).repeatForever(autoreverses: true)) {
                animateGradient.toggle()
            }
        }
    }
}

// MARK: - Bracelet Connection View
struct BraceletConnectionView: View {
    @State private var isAnimating = false
    
    var body: some View {
        HStack(spacing: 8) {
            Circle()
                .fill(Color.green)
                .frame(width: 8, height: 8)
                .scaleEffect(isAnimating ? 1.2 : 1.0)
                .opacity(isAnimating ? 0.5 : 1.0)
            
            Text("Connected")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(.white.opacity(0.8))
            
            Image(systemName: "applewatch.watchface")
                .font(.system(size: 20))
                .foregroundStyle(.white.opacity(0.6))
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.white.opacity(0.1), lineWidth: 1)
                )
        )
        .onAppear {
            withAnimation(.easeInOut(duration: 1.5).repeatForever()) {
                isAnimating = true
            }
        }
    }
}

// MARK: - Emotion Card - ULTRA PREMIUM DESIGN
struct EmotionCardView: View {
    let emotion: EmotionState
    @State private var shimmerOffset: CGFloat = -200
    @State private var particleOffset: CGFloat = 0
    
    var body: some View {
        ZStack {
            // Glass background with depth
            RoundedRectangle(cornerRadius: 32)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 32)
                        .stroke(
                            LinearGradient(
                                colors: [
                                    emotion.color.opacity(0.5),
                                    emotion.color.opacity(0.0)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 2
                        )
                )
                .shadow(color: emotion.color.opacity(0.3), radius: 30, x: 0, y: 15)
            
            VStack(spacing: 20) {
                // Emotion label with shimmer effect
                Text("EMOTION: \(emotion.name.uppercased())")
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                    .tracking(2)
                    .foregroundStyle(.white.opacity(0.9))
                    .overlay(
                        Rectangle()
                            .fill(
                                LinearGradient(
                                    colors: [
                                        .clear,
                                        .white.opacity(0.3),
                                        .clear
                                    ],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .frame(width: 100)
                            .offset(x: shimmerOffset)
                            .mask(
                                Text("EMOTION: \(emotion.name.uppercased())")
                                    .font(.system(size: 16, weight: .bold, design: .rounded))
                                    .tracking(2)
                            )
                    )
                
                // Animated emotion bar with particles
                ZStack(alignment: .leading) {
                    // Background track
                    Capsule()
                        .fill(Color.white.opacity(0.1))
                        .frame(height: 12)
                    
                    // Filled portion with gradient
                    Capsule()
                        .fill(
                            LinearGradient(
                                colors: emotion.gradientColors,
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: CGFloat(emotion.intensity) / 100 * (UIScreen.main.bounds.width - 120), height: 12)
                        .overlay(
                            // Glowing effect
                            Capsule()
                                .stroke(emotion.color.opacity(0.6), lineWidth: 2)
                                .blur(radius: 4)
                        )
                        .shadow(color: emotion.color.opacity(0.6), radius: 10, x: 0, y: 0)
                    
                    // Particle effect
                    ForEach(0..<5, id: \.self) { index in
                        Circle()
                            .fill(emotion.color.opacity(0.6))
                            .frame(width: 4, height: 4)
                            .offset(
                                x: particleOffset + CGFloat(index * 40),
                                y: CGFloat.random(in: -20...20)
                            )
                            .opacity(particleOffset > 0 ? 1 : 0)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.horizontal, 30)
                
                // Percentage
                Text("\(Int(emotion.intensity))%")
                    .font(.system(size: 24, weight: .bold, design: .rounded))
                    .foregroundStyle(emotion.color)
            }
            .padding(.vertical, 30)
        }
        .frame(height: 180)
        .padding(.horizontal, 20)
        .onAppear {
            startShimmer()
            startParticles()
        }
    }
    
    private func startShimmer() {
        withAnimation(.linear(duration: 2.5).repeatForever(autoreverses: false)) {
            shimmerOffset = 400
        }
    }
    
    private func startParticles() {
        withAnimation(.linear(duration: 3.0).repeatForever(autoreverses: false)) {
            particleOffset = UIScreen.main.bounds.width
        }
    }
}

#Preview {
    ContentView()
}

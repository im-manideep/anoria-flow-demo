import SwiftUI

// MARK: - Flow Score Display
struct FlowScoreDisplay: View {
    let score: Int
    @State private var animatedScore: Int = 0
    @State private var rotation: Double = 0
    
    var body: some View {
        VStack(spacing: 12) {
            ZStack {
                // Outer glow ring
                Circle()
                    .stroke(
                        LinearGradient(
                            colors: [
                                scoreColor.opacity(0.3),
                                scoreColor.opacity(0.0)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 3
                    )
                    .frame(width: 180, height: 180)
                    .blur(radius: 10)
                
                // Main circle
                Circle()
                    .fill(
                        RadialGradient(
                            colors: [
                                scoreColor.opacity(0.2),
                                scoreColor.opacity(0.05)
                            ],
                            center: .center,
                            startRadius: 0,
                            endRadius: 90
                        )
                    )
                    .frame(width: 160, height: 160)
                    .overlay(
                        Circle()
                            .stroke(scoreColor.opacity(0.3), lineWidth: 2)
                    )
                
                // Score number
                VStack(spacing: 4) {
                    Text("\(animatedScore)")
                        .font(.system(size: 72, weight: .bold, design: .rounded))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [.white, scoreColor],
                                startPoint: .top,
                                endPoint: .bottom
                            )
                        )
                    
                    Text("FLOW SCORE")
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                        .tracking(2)
                        .foregroundStyle(.white.opacity(0.6))
                }
            }
            .rotation3DEffect(
                .degrees(rotation),
                axis: (x: 0, y: 1, z: 0)
            )
            
            // Score indicator
            Text(scoreIndicator)
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(scoreColor)
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(
                    Capsule()
                        .fill(scoreColor.opacity(0.15))
                )
        }
        .onAppear {
            animateScore()
            startRotation()
        }
        .onChange(of: score) { _, newValue in
            animateScore()
        }
    }
    
    private var scoreColor: Color {
        if score > 80 {
            return Color(hex: "00FF87")
        } else if score > 60 {
            return Color(hex: "5AC8FA")
        } else if score > 40 {
            return Color(hex: "FFD60A")
        } else {
            return Color(hex: "FF3B30")
        }
    }
    
    private var scoreIndicator: String {
        if score > 80 {
            return "Excellent"
        } else if score > 60 {
            return "Good"
        } else if score > 40 {
            return "Fair"
        } else {
            return "Needs Attention"
        }
    }
    
    private func animateScore() {
        let duration = 1.5
        let steps = 60
        let increment = Double(score - animatedScore) / Double(steps)
        
        for i in 0...steps {
            DispatchQueue.main.asyncAfter(deadline: .now() + (duration / Double(steps)) * Double(i)) {
                animatedScore += Int(increment)
            }
        }
    }
    
    private func startRotation() {
        withAnimation(.linear(duration: 20.0).repeatForever(autoreverses: false)) {
            rotation = 360
        }
    }
}

// MARK: - Metric Bar View
struct MetricBarView: View {
    let title: String
    let value: Int
    let color: Color
    let icon: String
    
    @State private var animatedValue: Double = 0
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: icon)
                    .font(.system(size: 16))
                    .foregroundStyle(color)
                
                Text(title)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(.white)
                
                Spacer()
                
                Text("\(value)")
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .foregroundStyle(color)
            }
            
            // Progress bar
            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    // Background
                    Capsule()
                        .fill(Color.white.opacity(0.1))
                    
                    // Filled portion
                    Capsule()
                        .fill(
                            LinearGradient(
                                colors: [color, color.opacity(0.6)],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: geometry.size.width * animatedValue / 100)
                        .overlay(
                            Capsule()
                                .stroke(color.opacity(0.5), lineWidth: 1)
                                .blur(radius: 4)
                        )
                        .shadow(color: color.opacity(0.5), radius: 8, x: 0, y: 0)
                }
            }
            .frame(height: 10)
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(color.opacity(0.2), lineWidth: 1)
                )
        )
        .onAppear {
            withAnimation(.spring(response: 1.0, dampingFraction: 0.7)) {
                animatedValue = Double(value)
            }
        }
        .onChange(of: value) { _, newValue in
            withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                animatedValue = Double(newValue)
            }
        }
    }
}

// MARK: - Smart Recommendation Card
struct SmartRecommendationCard: View {
    let recommendation: Recommendation
    @State private var isHovered = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(recommendation.color.opacity(0.2))
                        .frame(width: 50, height: 50)
                    
                    Image(systemName: recommendation.icon)
                        .font(.system(size: 24))
                        .foregroundStyle(recommendation.color)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(recommendation.title)
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(.white)
                    
                    Text("Recommendation")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(.white.opacity(0.6))
                }
                
                Spacer()
            }
            
            Text(recommendation.description)
                .font(.system(size: 15))
                .foregroundStyle(.white.opacity(0.8))
                .lineSpacing(4)
            
            Button(action: {
                // Action handler
            }) {
                HStack {
                    Text(recommendation.action)
                        .font(.system(size: 16, weight: .semibold))
                    
                    Image(systemName: "arrow.right")
                        .font(.system(size: 14, weight: .semibold))
                }
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(
                    Capsule()
                        .fill(
                            LinearGradient(
                                colors: [
                                    recommendation.color,
                                    recommendation.color.opacity(0.7)
                                ],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                )
            }
        }
        .padding(24)
        .background(
            RoundedRectangle(cornerRadius: 24)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 24)
                        .stroke(
                            LinearGradient(
                                colors: [
                                    recommendation.color.opacity(0.5),
                                    recommendation.color.opacity(0.0)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 2
                        )
                )
        )
        .scaleEffect(isHovered ? 1.02 : 1.0)
        .shadow(color: recommendation.color.opacity(0.3), radius: 20, x: 0, y: 10)
        .onAppear {
            withAnimation(.easeInOut(duration: 2.0).repeatForever(autoreverses: true)) {
                isHovered = true
            }
        }
    }
}

// MARK: - Recent Activity Preview
struct RecentActivityPreview: View {
    @ObservedObject var emotionEngine: EmotionEngine
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Recent Activity")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.white)
                
                Spacer()
                
                Button(action: {}) {
                    HStack(spacing: 4) {
                        Text("View All")
                            .font(.system(size: 14, weight: .medium))
                        Image(systemName: "chevron.right")
                            .font(.system(size: 12))
                    }
                    .foregroundStyle(Color.cyan)
                }
            }
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(emotionEngine.emotionHistory.suffix(10).reversed(), id: \.0) { date, emotion in
                        ActivityPillView(date: date, emotion: emotion)
                    }
                }
            }
        }
        .padding(.vertical, 8)
    }
}

struct ActivityPillView: View {
    let date: Date
    let emotion: EmotionState
    
    var body: some View {
        VStack(spacing: 8) {
            Circle()
                .fill(emotion.color)
                .frame(width: 12, height: 12)
            
            Text(date, style: .time)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.white.opacity(0.7))
            
            Text(emotion.name)
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(emotion.color)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(emotion.color.opacity(0.3), lineWidth: 1)
                )
        )
    }
}
